"""Windows desktop companion for Yecatz."""
import json
import math
import os
import random
import sys
import threading
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from pathlib import Path

import keyring
from send2trash import send2trash
from PySide6.QtCore import Qt, QTimer, Signal, QObject, QRectF, QPoint, QUrl
from PySide6.QtGui import QAction, QFontDatabase, QIcon, QPainter, QPixmap, QColor, QPainterPath, QPen
from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
from PySide6.QtWidgets import (
    QApplication, QDialog, QDialogButtonBox, QFormLayout, QInputDialog,
    QLineEdit, QMenu, QMessageBox, QSystemTrayIcon, QVBoxLayout, QWidget,
)

VERSION = "0.1.1"
ROOT = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent.parent))
ASSETS = ROOT / "Assets"
DATA = Path(os.environ.get("APPDATA", Path.home())) / "Yecatz"
SETTINGS = DATA / "settings.json"
SERVICE = "Yecatz"
QUOTES = ["慢一点，也是在往前。", "允许答案晚一点来。", "日子不用每页都写满。",
          "有些路，走着才看得清。", "先看脚下，再看远方。", "你可以边走边改变主意。"]
PERSONA = (ROOT / "persona.txt").read_text(encoding="utf-8")


def load_settings():
    try:
        data = json.loads(SETTINGS.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def save_settings(data):
    DATA.mkdir(parents=True, exist_ok=True)
    tmp = SETTINGS.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    tmp.replace(SETTINGS)


def get_json(url, body=None, headers=None):
    payload = json.dumps(body).encode("utf-8") if body is not None else None
    request = urllib.request.Request(url, data=payload, headers=headers or {})
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, req, fp, code, msg, hdrs, newurl):
            return None
    opener = urllib.request.build_opener(NoRedirect()) if body is not None else urllib.request.build_opener()
    with opener.open(request, timeout=15) as response:
        return json.load(response)


def valid_api_url(value):
    url = urllib.parse.urlparse(value)
    return url.scheme == "https" and bool(url.hostname) and not url.username and not url.password


class Signals(QObject):
    reply = Signal(str)
    api_done = Signal(str)
    update = Signal(str, str)
    music = Signal(str, str)


class SettingsDialog(QDialog):
    def __init__(self, settings, parent):
        super().__init__(parent)
        self.setWindowTitle("Yecatz 聊天设置")
        self.url = QLineEdit(settings.get("api_url", "https://openrouter.ai/api/v1"))
        self.model = QLineEdit(settings.get("model", "openrouter/free"))
        self.key = QLineEdit()
        self.key.setEchoMode(QLineEdit.EchoMode.Password)
        self.key.setPlaceholderText("留空保留现有密钥")
        form = QFormLayout(self)
        form.addRow("API 地址", self.url)
        form.addRow("模型", self.model)
        form.addRow("API 密钥", self.key)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        form.addRow(buttons)

    def accept(self):
        if not valid_api_url(self.url.text().strip()) or not self.model.text().strip():
            QMessageBox.warning(self, "Yecatz", "请输入 HTTPS API 地址和模型名。")
            return
        super().accept()


class Pet(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint | Qt.WindowType.Tool)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAcceptDrops(True)
        self.resize(220, 265)
        self.cat = QPixmap(str(ASSETS / "cat.png"))
        self.blink = QPixmap(str(ASSETS / "cat-blink.png"))
        self.entry = QPixmap(str(ASSETS / "cat-entry.png"))
        if self.cat.isNull() or self.blink.isNull() or self.entry.isNull():
            raise RuntimeError("缺少 Yecatz 图片素材。")
        self.font_id = QFontDatabase.addApplicationFont(str(ASSETS / "pixel-zh-hans.ttf"))
        self.settings = load_settings()
        self.signals = Signals()
        self.signals.reply.connect(self.say)
        self.signals.api_done.connect(self.finish_api)
        self.signals.update.connect(self.show_update)
        self.signals.music.connect(self.play_media)
        self.player = QMediaPlayer(self)
        self.audio = QAudioOutput(self)
        self.player.setAudioOutput(self.audio)
        self.player.errorOccurred.connect(self.media_error)
        self.context = []
        self.api_busy = False
        self.drag_start = None
        self.moved = False
        self.tick = 0
        self.blink_until = 0
        self.next_blink = random.randrange(40, 100)
        self.bubble = ""
        self.bubble_pages = []
        self.bubble_start = 0
        self.bubble_until = 0
        self.phase = ""
        self.action = None
        self.action_start = 0
        self.force_monster = False
        self.phase_until = 0
        self.awaiting_city = False
        self.single_timer = QTimer(self)
        self.single_timer.setSingleShot(True)
        self.single_timer.timeout.connect(self.single_click)
        self.anim = QTimer(self)
        self.anim.timeout.connect(self.advance)
        self.anim.start(50)
        self.hourly = QTimer(self)
        self.hourly.timeout.connect(self.hourly_quote)
        self.hourly.start(3600000)
        self.tray = QSystemTrayIcon(QIcon(str(ASSETS / "tie-status.png")), self)
        self.tray.setToolTip("Yecatz")
        menu = QMenu()
        self.add_action(menu, "和 Yecatz 聊天", self.chat)
        self.add_action(menu, "聊天设置…", self.configure)
        self.add_action(menu, "显示 Yecatz", self.show)
        self.add_action(menu, "隐藏 Yecatz", self.hide)
        self.add_action(menu, "检查更新…", lambda: self.check_update(True))
        menu.addSeparator()
        self.add_action(menu, "退出 Yecatz", QApplication.quit)
        self.tray.setContextMenu(menu)
        self.tray.activated.connect(self.tray_click)
        self.tray.show()
        screen = QApplication.primaryScreen().availableGeometry()
        self.target_x = screen.right() - self.width() - 15
        self.entry_x = screen.right() + 1
        self.move(self.entry_x, screen.bottom() - self.height())
        self.entering = True
        self.entry_tick = 0
        self.show()
        self.thread(self.check_update, False)

    @staticmethod
    def add_action(menu, text, callback):
        action = QAction(text, menu)
        action.triggered.connect(callback)
        menu.addAction(action)

    def tray_click(self, reason):
        if reason == QSystemTrayIcon.ActivationReason.Trigger:
            self.show()
            self.raise_()

    def thread(self, fn, *args):
        threading.Thread(target=fn, args=args, daemon=True).start()

    def advance(self):
        self.tick += 1
        if self.phase == "trash" and self.tick >= self.phase_until:
            self.phase = ""
        if self.tick >= self.next_blink:
            self.blink_until = self.tick + 3
            self.next_blink = self.tick + random.randrange(60, 140)
        if self.entering:
            self.entry_tick += 1
            progress = min(1, self.entry_tick / 40)
            self.move(round(self.entry_x + (self.target_x - self.entry_x) * (1 - (1 - progress) ** 2)), self.y())
            if self.entry_tick >= 48:
                self.entering = False
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, False)
        if self.entering:
            frame = [0, 2, 1, 2][(self.entry_tick // 3) % 4] if self.entry_tick < 40 else (2 if self.entry_tick < 44 else 3)
            width = self.entry.width() // 4
            sprite = self.entry.copy(frame * width, 0, width, self.entry.height())
        else:
            sprite = self.blink if self.tick < self.blink_until and self.phase != "trash" else self.cat
        breath = 0 if self.entering else 2 * math.sin(self.tick * 0.1)
        action_frame = (self.tick - self.action_start) // 2
        if self.action and action_frame < 10 and not self.entering and self.phase != "trash":
            painter.save()
            painter.translate(0, 265)
            painter.scale(1, -1)
            self.draw_action(painter, action_frame)
            painter.restore()
        else:
            self.action = None
            painter.drawPixmap(QRectF(20, 41 - breath, 180, 220 + breath), sprite, QRectF(sprite.rect()))
        if self.phase == "trash" and self.tick < self.phase_until:
            elapsed = 72 - (self.phase_until - self.tick)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QColor("#17171d"))
            painter.drawRect(74, 104, 30, 13)
            painter.drawRect(120, 104, 30, 13)
            painter.drawRect(101, 107, 22, 3)
            painter.setBrush(QColor("#fff2dc"))
            if elapsed < 52:
                painter.drawRect(131, 161 + min(20, elapsed // 4), 24, max(2, 30 - max(0, elapsed - 20)))
            if 20 < elapsed < 58:
                painter.setBrush(QColor("#ff7927"))
                painter.drawEllipse(133, 157 + min(20, elapsed // 4), 13, 16)
        if self.bubble and self.tick < self.bubble_until:
            page = min((self.tick - self.bubble_start) // 120, len(self.bubble_pages) - 1)
            painter.setPen(QColor("#30242a"))
            painter.setBrush(QColor("#fff7e8"))
            painter.drawRoundedRect(5, 4, 210, 58, 5, 5)
            painter.drawText(QRectF(9, 6, 202, 54), Qt.AlignmentFlag.AlignCenter | Qt.TextFlag.TextWordWrap, self.bubble_pages[page])

    def say(self, text):
        self.bubble = text
        self.bubble_pages = [text[index:index + 44] for index in range(0, len(text), 44)] or [""]
        self.bubble_start = self.tick
        self.bubble_until = self.tick + 120 * len(self.bubble_pages)
        self.update()

    def finish_api(self, text):
        self.api_busy = False
        self.say(text)

    def hourly_quote(self):
        if self.isVisible() and self.tick >= self.bubble_until:
            self.say(random.choice(QUOTES))

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.entering = False
            self.drag_start = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            self.moved = False
            self.force_monster = bool(event.modifiers() & Qt.KeyboardModifier.AltModifier)

    def mouseMoveEvent(self, event):
        if self.drag_start is not None and event.buttons() & Qt.MouseButton.LeftButton:
            self.move(event.globalPosition().toPoint() - self.drag_start)
            self.moved = True

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton and not self.moved:
            self.single_timer.start(QApplication.doubleClickInterval())
        self.drag_start = None

    def mouseDoubleClickEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.single_timer.stop()
            self.moved = True
            self.action, self.action_start = "hug", self.tick
            self.say("♡ 给你一个抱抱 ♡")

    def single_click(self):
        self.action = "monster" if self.force_monster or random.randrange(25) == 0 else random.choice(["wave", "flower", "tear"])
        self.action_start = self.tick
        messages = {"wave": "Hi，I'm Yecatz", "flower": "Enjoy Ur Day :)",
                    "tear": "I hate being bi-polar...", "monster": "I'm motfuc Monster！"}
        self.say(messages[self.action])

    def draw_action(self, painter, frame):
        wave = [-25, -80, -125, -146, -123, -146, -146, -146, -85, -30]
        flower = [0.12, 0.38, 0.72, 1, 1, 1, 1, 0.78, 0.49, 0.21]
        claw = [0.04, 0.2, 0.45, 0.8, 1, 1, 1, 0.8, 0.5, 0.15]
        left = wave[frame] if self.action == "wave" else (-129 * claw[frame] if self.action == "monster" else 0)
        right = -100 * flower[frame] if self.action == "flower" else (129 * claw[frame] if self.action == "monster" else 0)
        body = QPainterPath()
        body.addRect(QRectF(20, 4, 180, 220))
        sleeve = [(52, 44), (80, 44), (80, 63), (82, 79), (85, 94), (88, 109), (52, 109)]
        for angle, mirror in ((left, False), (right, True)):
            if abs(angle) < 0.5:
                continue
            cut = QPainterPath()
            for index, (x, y) in enumerate(sleeve):
                x = 220 - x if mirror else x
                (cut.moveTo if index == 0 else cut.lineTo)(x, y)
            cut.closeSubpath()
            body = body.subtracted(cut)
        painter.save()
        painter.setClipPath(body)
        painter.drawPixmap(QRectF(20, 4, 180, 220), self.cat, QRectF(self.cat.rect()))
        painter.restore()
        for angle, mirror in ((left, False), (right, True)):
            if abs(angle) < 0.5:
                continue
            bend = -angle if mirror else angle
            shoulder = (83.0, 103.0)
            def advance(point, length, degrees):
                radians = math.radians(degrees)
                return (point[0] + length * math.sin(radians), point[1] - length * math.cos(radians))
            elbow = advance(shoulder, 23, -22 + 0.27 * bend)
            direction = max(-164, -3 + 1.10 * bend)
            wrist = advance(elbow, 20, direction)
            def px(point):
                return 220 - point[0] if mirror else point[0]
            painter.save()
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, False)
            for color, width in (("#131018", 17), ("#343138", 13)):
                pen = QPen(QColor(color), width)
                pen.setCapStyle(Qt.PenCapStyle.RoundCap)
                pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
                painter.setPen(pen)
                path = QPainterPath()
                path.moveTo(px(shoulder), shoulder[1])
                path.lineTo(px(elbow), elbow[1])
                path.lineTo(px(wrist), wrist[1])
                painter.drawPath(path)
            painter.translate(px(wrist), wrist[1])
            if mirror:
                painter.scale(-1, 1)
            painter.rotate(direction)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QColor("#16131a"))
            painter.drawRect(-8, -3, 16, 8)
            painter.setBrush(QColor("#f5e5dd"))
            painter.drawRect(-6, -1, 12, 4)
            painter.setBrush(QColor("#382316"))
            painter.drawRoundedRect(QRectF(-7, -12, 14, 12), 2, 2)
            painter.setBrush(QColor("#d4925c"))
            painter.drawRect(-5, -10, 10, 8)
            if self.action == "monster":
                painter.setBrush(QColor("#fff0cf"))
                for x in (-4, 0, 4):
                    painter.drawRect(x, -16, 2, 6)
            painter.restore()
            if self.action == "flower" and mirror:
                paw = advance(wrist, 6, direction)
                x, y = px(paw), paw[1]
                painter.setPen(QPen(QColor("#398144"), 2))
                painter.drawLine(int(x), int(y), int(x), int(y + 18))
                painter.setPen(Qt.PenStyle.NoPen)
                painter.setBrush(QColor("#e73149"))
                painter.drawEllipse(QRectF(x - 5, y + 16, 10, 10))
        painter.setPen(Qt.PenStyle.NoPen)
        if self.action == "tear":
            y = 142 - frame * 4
            painter.setBrush(QColor("#1da8ff"))
            painter.drawEllipse(QRectF(77, y - 16, 13, 18))
            painter.setBrush(QColor("#c9f5ff"))
            painter.drawRect(80, int(y - 8), 3, 5)
        elif self.action == "monster":
            painter.setBrush(QColor("#bb1230"))
            painter.drawRect(73, 146, 27, 15)
            painter.drawRect(120, 146, 27, 15)
            painter.drawRect(99, 153, 23, 3)
            painter.setBrush(QColor("#ff6a17"))
            painter.drawRect(80, 157, 6, 7 + frame % 3)
            painter.drawRect(130, 157, 6, 7 + frame % 3)
        elif self.action == "hug":
            painter.setBrush(QColor("#ff76b1"))
            for i in range(4):
                x = 55 + i * 36 + (frame * 2 if i % 2 else -frame * 2)
                y = 80 + frame * 8 + i * 9
                painter.drawEllipse(QRectF(x, y, 7, 7))
                painter.drawEllipse(QRectF(x + 5, y, 7, 7))
                heart = QPainterPath()
                heart.moveTo(x, y + 3)
                heart.lineTo(x + 6, y - 5)
                heart.lineTo(x + 12, y + 3)
                heart.closeSubpath()
                painter.drawPath(heart)

    def contextMenuEvent(self, event):
        self.tray.contextMenu().popup(event.globalPos())

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls() and all(url.isLocalFile() for url in event.mimeData().urls()):
            event.setDropAction(Qt.DropAction.CopyAction)
            event.accept()

    def dropEvent(self, event):
        files = [url.toLocalFile() for url in event.mimeData().urls() if url.isLocalFile()]
        successes = 0
        for file in files:
            try:
                send2trash(file)
                successes += 1
            except (OSError, RuntimeError):
                pass
        if successes:
            self.phase = "trash"
            self.phase_until = self.tick + 72
            event.setDropAction(Qt.DropAction.CopyAction)
            event.accept()
        self.say(f"已移入回收站 {successes} 个，失败 {len(files) - successes} 个。")

    def configure(self):
        dialog = SettingsDialog(self.settings, self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        key = dialog.key.text().strip()
        if key:
            try:
                keyring.set_password(SERVICE, "api-key", key)
            except keyring.errors.KeyringError:
                QMessageBox.warning(self, "Yecatz", "无法保存密钥，请检查 Windows 凭据管理器。")
                return
        self.settings["api_url"] = dialog.url.text().strip().rstrip("/")
        self.settings["model"] = dialog.model.text().strip()
        try:
            save_settings(self.settings)
        except OSError:
            QMessageBox.warning(self, "Yecatz", "保存设置失败。")

    def chat(self):
        text, ok = QInputDialog.getText(self, "和 Yecatz 聊天", "说点什么：")
        text = text.strip()[:1200]
        if not ok or not text:
            return
        if self.awaiting_city:
            self.awaiting_city = False
            self.thread(self.weather, text)
        elif "天气" in text:
            city = self.settings.get("city")
            if city:
                self.thread(self.weather, city)
            else:
                self.awaiting_city = True
                self.say("你在哪个城市？")
        elif any(word in text for word in ("几点了", "现在几点")):
            from datetime import datetime
            self.say("现在 " + datetime.now().strftime("%H:%M"))
        elif any(word in text for word in ("放点音乐", "放首歌", "来首歌", "放一首你喜欢", "推荐一首歌", "播放音乐")):
            self.thread(self.find_music)
        elif text in ("暂停", "停一下", "别放了"):
            self.player.pause()
            self.say("先停一下。")
        else:
            if self.api_busy:
                self.say("等我回完这一句。")
                return
            self.api_busy = True
            self.thread(self.ask, text)

    def find_music(self):
        folder = Path.home() / "Music" / "Yecatz"
        files = sorted(p for p in folder.glob("*") if p.suffix.lower() in {".mp3", ".m4a", ".wav", ".aac"}) if folder.is_dir() else []
        if files:
            self.signals.music.emit(QUrl.fromLocalFile(str(random.choice(files))).toString(), "放首本地音乐。")
            return
        artist, title = random.choice([
            ("Radiohead", "Weird Fishes / Arpeggi"),
            ("Frank Ocean", "Pink + White"),
            ("Daft Punk", "Digital Love"),
        ])
        try:
            query = urllib.parse.urlencode({"term": f"{artist} {title}", "entity": "song", "limit": 8, "country": "us"})
            matches = get_json("https://itunes.apple.com/search?" + query).get("results", [])
            def normalized(value):
                return "".join(c for c in value.casefold() if c.isalnum())
            for item in matches:
                preview = urllib.parse.urlparse(item.get("previewUrl", ""))
                if (normalized(item.get("artistName", "")) == normalized(artist)
                        and normalized(item.get("trackName", "")).startswith(normalized(title))
                        and preview.scheme == "https"):
                    self.signals.music.emit(preview.geturl(), f"放首 {artist} 的《{title}》（试听）。")
                    return
        except (OSError, ValueError):
            pass
        self.signals.reply.emit("暂时没有找到可播放的版本。")

    def play_media(self, url, message):
        self.player.stop()
        self.player.setSource(QUrl(url))
        self.player.play()
        self.say(message)

    def media_error(self, error, message):
        if error != QMediaPlayer.Error.NoError:
            self.say("这首歌没能播放，请检查文件或网络。")

    def weather(self, city):
        try:
            query = urllib.parse.urlencode({"name": city, "count": 1, "language": "zh"})
            places = get_json("https://geocoding-api.open-meteo.com/v1/search?" + query).get("results", [])
            if not places:
                self.signals.reply.emit("没找到这个城市，请再试一次。")
                return
            place = places[0]
            query = urllib.parse.urlencode({"latitude": place["latitude"], "longitude": place["longitude"],
                                            "current": "temperature_2m,weather_code", "timezone": "auto"})
            result = get_json("https://api.open-meteo.com/v1/forecast?" + query)
            self.settings["city"] = city
            save_settings(self.settings)
            self.signals.reply.emit(f'{place["name"]}现在 {round(result["current"]["temperature_2m"])}°C。数据：Open-Meteo')
        except (OSError, ValueError, KeyError):
            self.signals.reply.emit("天气暂时查不到，稍后再试。")

    def ask(self, text):
        try:
            key = keyring.get_password(SERVICE, "api-key")
            base = self.settings.get("api_url", "https://openrouter.ai/api/v1").rstrip("/")
            if not key or not valid_api_url(base):
                self.signals.api_done.emit("请先从托盘菜单打开聊天设置。")
                return
            messages = [{"role": "system", "content": PERSONA}] + self.context[-6:] + [{"role": "user", "content": text}]
            result = get_json(base + "/chat/completions",
                              {"model": self.settings.get("model", "openrouter/free"), "messages": messages, "stream": False},
                              {"Authorization": "Bearer " + key, "Content-Type": "application/json"})
            answer = result["choices"][0]["message"]["content"].strip()
            if not answer:
                raise ValueError("empty reply")
            self.context.extend([{"role": "user", "content": text}, {"role": "assistant", "content": answer}])
            self.context = self.context[-6:]
            self.signals.api_done.emit(answer)
        except (OSError, ValueError, TypeError, AttributeError, KeyError, IndexError, keyring.errors.KeyringError):
            self.signals.api_done.emit("暂时连不上聊天服务，请检查网络和设置。")

    def check_update(self, manual=False):
        try:
            release = get_json("https://api.github.com/repos/YenningC/Yecatz/releases/latest",
                               headers={"Accept": "application/vnd.github+json", "User-Agent": "Yecatz/" + VERSION})
            tag = release["tag_name"]
            def version(value):
                parts = [int(part) for part in value.lstrip("vV").split(".")]
                return tuple(parts + [0] * max(0, 3 - len(parts)))
            url = urllib.parse.urlparse(release["html_url"])
            has_windows = any(item.get("name") == "Yecatz-Windows-x64.zip" for item in release.get("assets", []))
            if (has_windows and not release["prerelease"] and not release["draft"] and version(tag) > version(VERSION)
                    and url.scheme == "https" and url.netloc.lower() == "github.com"
                    and url.path.lower().startswith("/yenningc/yecatz/releases/")):
                self.signals.update.emit(tag, release["html_url"])
            elif manual:
                self.signals.reply.emit("暂无适用于 Windows 的新版本。")
        except (OSError, ValueError, KeyError):
            if manual:
                self.signals.reply.emit("暂时无法检查更新。")

    def show_update(self, tag, url):
        result = QMessageBox.question(self, "Yecatz 更新", f"发现 {tag}，打开下载页面吗？")
        if result == QMessageBox.StandardButton.Yes:
            webbrowser.open(url)


def main():
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)
    pet = Pet()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
