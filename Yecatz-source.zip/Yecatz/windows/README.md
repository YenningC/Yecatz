# Yecatz for Windows

这是 Windows 移植中的开发版本，尚未在 Windows 上完成实机验证。它使用独立的 Qt 窗口实现桌宠，而非运行 macOS 应用。

目前已实现透明悬浮窗口、入场、眨眼、挥手、送花、泪水、抱抱、回收站拖放、API 聊天、天气查询、本地音乐或在线试听、托盘菜单、每小时短句和 GitHub 更新检查。动画及功能与 macOS 版本仍有差异，例如聊天暂不保存长期记忆，音乐控制和天气指令的覆盖范围也较少。

## 在 Windows 上构建

需要 64 位 Windows 和 Python 3.12。打开 PowerShell，在项目根目录运行：

```powershell
.\windows\build.ps1
```

构建完成后，`dist\Yecatz-Windows-x64.zip` 包含运行所需的文件。解压整个文件夹并运行 `Yecatz.exe`。

也可以将完整源码和 `.github/workflows/windows.yml` 上传到 GitHub，在仓库的 Actions 页面运行 **Build Windows**。构建完成后，从该次运行的 Artifacts 下载压缩包；只有在 Windows 上实测通过后再附到 Release。

## 使用

右键 Yecatz 或点击托盘图标打开菜单。选择「聊天设置…」填写 HTTPS API 地址、模型和密钥；密钥保存在系统凭据管理器。

聊天选择「和 Yecatz 聊天」，输入「今天天气怎么样」可查询天气，首次输入城市名称。音乐文件可放进用户目录的 `Music\Yecatz` 文件夹；没有本地音乐时会尝试播放试听。把文件拖到 Yecatz 身上会移入 Windows 回收站。

Qt、字体和其他依赖的许可证请在正式分发前一并核对。
